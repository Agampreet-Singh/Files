<?php
// ============================================
// Cosmos Bank CBS - Database Configuration
// ============================================

$DB_HOST = "localhost";
$DB_NAME = "cosmos_bank";
$DB_USER = "root";
$DB_PASS = "";   // set your MySQL root password here if you have one

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
