-- ============================================
-- Cosmos Bank - Core Banking System (CBS)
-- Database Schema
-- Run this in phpMyAdmin or via mysql CLI:
--   mysql -u root -p < schema.sql
-- ============================================

CREATE DATABASE IF NOT EXISTS cosmos_bank;
USE cosmos_bank;

-- ---------------------------------
-- Admin users (portal login)
-- ---------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(30) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default admin login: username = admin | password = Admin@123
-- (change this after first login)
INSERT INTO admin_users (username, password_hash, full_name, role)
VALUES ('admin', '$2y$10$h930DL6eouYDz2ItpdaLiOHFEV8O63vSiXF7..5g/1fxCrH9QrnfS', 'Bank Administrator', 'admin')
ON DUPLICATE KEY UPDATE username = username;
-- NOTE: the hash above corresponds to password: Admin@123

-- ---------------------------------
-- Customers
-- ---------------------------------
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(15),
    kyc_id VARCHAR(30),
    branch VARCHAR(50) DEFAULT 'Head Office',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO customers (full_name, email, phone, kyc_id, branch) VALUES
('Ramesh Kulkarni', 'ramesh.k@example.com', '9822011111', 'KYC10001', 'Pune Branch'),
('Ananya Sharma', 'ananya.s@example.com', '9822022222', 'KYC10002', 'Mumbai Branch'),
('Vikram Singh', 'vikram.s@example.com', '9822033333', 'KYC10003', 'Head Office'),
('Priya Nair', 'priya.n@example.com', '9822044444', 'KYC10004', 'Mumbai Branch'),
('Arjun Mehta', 'arjun.m@example.com', '9822055555', 'KYC10005', 'Pune Branch');

-- ---------------------------------
-- Cards (linked to customers)
-- ---------------------------------
CREATE TABLE IF NOT EXISTS cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    card_number VARCHAR(20) UNIQUE NOT NULL,
    pin VARCHAR(255) NOT NULL,
    balance DECIMAL(14,2) DEFAULT 0.00,
    status ENUM('active','blocked') DEFAULT 'active',
    issued_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

-- PINs below are bcrypt-hashed (plaintext shown here in comments for lab reference only):
-- Card ...1001 -> PIN 1234
-- Card ...1002 -> PIN 2345
-- Card ...1003 -> PIN 3456
-- Card ...1004 -> PIN 4567
-- Card ...1005 -> PIN 5678
INSERT INTO cards (customer_id, card_number, pin, balance, status) VALUES
(1, '4000123456781001', '$2y$10$o5HRJa8qtq8cSeSsDjC42e0NSqoeaxPkE/YPXzVe2lLmRhzymJCum', 85000.00, 'active'),
(2, '4000123456781002', '$2y$10$H.FCidCzCRaY3CJrg3eUjOI9A6ZbOKMHQAJTWbUdZOw03tO1qjh3i', 152000.00, 'active'),
(3, '4000123456781003', '$2y$10$JnH8x9oim3W.Za7V8vZlru7Yd0kNd0HoqC89C.dIoxAM7yXze98kq', 42000.00, 'active'),
(4, '4000123456781004', '$2y$10$KfGsk19EHwXoa0zZKSp6Qu/MzBsQvXP6sdJt66CFhDf/NLkDtdYZG', 9800.00, 'active'),
(5, '4000123456781005', '$2y$10$yLHOyA2zXsC//r.H3MlFWO43Iy8Z6wZhwWkkl1xhjioUklK.edvmC', 210000.00, 'blocked');

-- ---------------------------------
-- Transactions (populated by ATM Switch queries later)
-- ---------------------------------
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_number VARCHAR(20) NOT NULL,
    atm_id VARCHAR(30) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    status ENUM('approved','declined') NOT NULL,
    reason VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- A couple of sample historical transactions for realism
INSERT INTO transactions (card_number, atm_id, amount, status, reason) VALUES
('4000123456781001', 'PUNE', 2000.00, 'approved', 'Transaction successful'),
('4000123456781002', 'MUMBAI', 5000.00, 'approved', 'Transaction successful'),
('4000123456781004', 'PUNE', 15000.00, 'declined', 'Insufficient balance');

-- ---------------------------------
-- Remote DB user for ATM Switch server
-- Replace <ATM_SWITCH_IP> with the actual IP of the ATM Switch machine
-- ---------------------------------
-- CREATE USER 'atmswitch'@'<ATM_SWITCH_IP>' IDENTIFIED BY 'ChangeThisPassword!123';
-- GRANT SELECT, UPDATE ON cosmos_bank.cards TO 'atmswitch'@'<ATM_SWITCH_IP>';
-- GRANT INSERT ON cosmos_bank.transactions TO 'atmswitch'@'<ATM_SWITCH_IP>';
-- FLUSH PRIVILEGES;
