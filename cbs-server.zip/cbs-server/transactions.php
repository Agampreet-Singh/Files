<?php
require 'includes/auth.php';
require 'config.php';

$filter = $_GET['status'] ?? '';
$sql = "SELECT * FROM transactions";
$params = [];
if ($filter === 'approved' || $filter === 'declined') {
    $sql .= " WHERE status = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY created_at DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

require 'includes/header.php';
?>
<div class="page-title">Transactions</div>
<div class="page-sub">Full transaction log across all ATMs</div>

<div class="panel" style="margin-bottom:16px;">
  <a href="transactions.php" class="btn btn-outline">All</a>
  <a href="transactions.php?status=approved" class="btn btn-outline">Approved</a>
  <a href="transactions.php?status=declined" class="btn btn-outline">Declined</a>
</div>

<div class="panel">
  <table>
    <tr><th>ID</th><th>Card Number</th><th>ATM</th><th>Amount</th><th>Status</th><th>Reason</th><th>Time</th></tr>
    <?php foreach ($transactions as $tx): ?>
    <tr>
      <td>#<?= $tx['id'] ?></td>
      <td><?= htmlspecialchars($tx['card_number']) ?></td>
      <td><?= htmlspecialchars($tx['atm_id']) ?></td>
      <td>₹<?= number_format($tx['amount'], 2) ?></td>
      <td><span class="badge badge-<?= $tx['status'] ?>"><?= ucfirst($tx['status']) ?></span></td>
      <td><?= htmlspecialchars($tx['reason']) ?></td>
      <td><?= date('d M, h:i A', strtotime($tx['created_at'])) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($transactions)): ?>
    <tr><td colspan="7" style="text-align:center; color:#8a9a9a; padding:24px;">No transactions found</td></tr>
    <?php endif; ?>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
