<?php
// ============================================
// ONE-TIME MIGRATION: Hash existing plaintext PINs
// Run this once by visiting it in the browser:
//   http://localhost/cbs/migrate_pins.php
// Safe to run multiple times — it skips PINs that are already hashed.
// Delete this file after running it once.
// ============================================

require 'config.php';

echo "<pre>";

// 1. Widen the pin column so it can hold a bcrypt hash (60 chars)
try {
    $pdo->exec("ALTER TABLE cards MODIFY pin VARCHAR(255) NOT NULL");
    echo "Step 1: cards.pin column widened to VARCHAR(255) — OK\n";
} catch (PDOException $e) {
    echo "Step 1: " . $e->getMessage() . " (probably already done, continuing)\n";
}

// 2. Hash any PIN that still looks like a plain 4-digit value
$rows = $pdo->query("SELECT id, card_number, pin FROM cards")->fetchAll(PDO::FETCH_ASSOC);
$updated = 0;

foreach ($rows as $row) {
    $pin = $row['pin'];
    // Bcrypt hashes always start with $2y$ (or $2b$/$2a$) and are 60 chars long.
    // Anything shorter/without that prefix is still plaintext.
    if (strlen($pin) < 20) {
        $hashed = password_hash($pin, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE cards SET pin = ? WHERE id = ?");
        $stmt->execute([$hashed, $row['id']]);
        echo "Hashed PIN for card {$row['card_number']}\n";
        $updated++;
    }
}

echo "\nDone. $updated card(s) updated. " . (count($rows) - $updated) . " card(s) were already hashed.\n";
echo "\nYou can now delete this file (migrate_pins.php) from the server.\n";
echo "</pre>";
