<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cosmos Bank CBS — Admin Portal</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-mark">CB</div>
      <div>
        <div class="brand-name">Cosmos Bank</div>
        <div class="brand-sub">Core Banking System</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">Dashboard</a>
      <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>">Customers</a>
      <a href="cards.php" class="<?= basename($_SERVER['PHP_SELF'])=='cards.php'?'active':'' ?>">Cards</a>
      <a href="transactions.php" class="<?= basename($_SERVER['PHP_SELF'])=='transactions.php'?'active':'' ?>">Transactions</a>
    </nav>
    <a href="logout.php" class="logout-link">Log out</a>
  </aside>
  <main class="content">
