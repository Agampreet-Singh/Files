<?php
require 'includes/auth.php';
require 'config.php';

$message = "";

// Handle add/edit card submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = trim($_POST['card_number']);
    $pin = trim($_POST['pin']);
    $balance = floatval($_POST['balance']);
    $status = $_POST['status'];
    $customer_id = !empty($_POST['customer_id']) ? intval($_POST['customer_id']) : null;

    $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_number = ?");
    $stmt->execute([$card_number]);
    $existing = $stmt->fetch();

    if ($existing) {
        $stmt = $pdo->prepare("UPDATE cards SET pin=?, balance=?, status=?, customer_id=? WHERE card_number=?");
        $stmt->execute([$pin, $balance, $status, $customer_id, $card_number]);
        $message = "Card $card_number updated successfully.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO cards (customer_id, card_number, pin, balance, status) VALUES (?,?,?,?,?)");
        $stmt->execute([$customer_id, $card_number, $pin, $balance, $status]);
        $message = "New card $card_number created successfully.";
    }
}

$cards = $pdo->query("
    SELECT cd.*, c.full_name FROM cards cd
    LEFT JOIN customers c ON c.id = cd.customer_id
    ORDER BY cd.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$customers = $pdo->query("SELECT id, full_name FROM customers ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);

require 'includes/header.php';
?>
<div class="page-title">Cards</div>
<div class="page-sub">Manage ATM/debit cards, balances, and status</div>

<?php if ($message): ?><div class="success-msg"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<div class="panel">
  <h3>Add / Update Card</h3>
  <form method="POST" class="inline-form">
    <div class="field">
      <label>Card Number</label>
      <input type="text" name="card_number" placeholder="4000123456789999" required>
    </div>
    <div class="field">
      <label>PIN</label>
      <input type="text" name="pin" maxlength="4" placeholder="1234" required>
    </div>
    <div class="field">
      <label>Balance (₹)</label>
      <input type="number" step="0.01" name="balance" placeholder="50000.00" required>
    </div>
    <div class="field">
      <label>Status</label>
      <select name="status">
        <option value="active">Active</option>
        <option value="blocked">Blocked</option>
      </select>
    </div>
    <div class="field">
      <label>Link to Customer (optional)</label>
      <select name="customer_id">
        <option value="">— None —</option>
        <?php foreach ($customers as $c): ?>
          <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Save Card</button>
  </form>
</div>

<div class="panel">
  <h3>All Cards</h3>
  <table>
    <tr><th>Card Number</th><th>Customer</th><th>Balance</th><th>Status</th><th>Issued</th></tr>
    <?php foreach ($cards as $c): ?>
    <tr>
      <td><?= htmlspecialchars($c['card_number']) ?></td>
      <td><?= htmlspecialchars($c['full_name'] ?? '—') ?></td>
      <td>₹<?= number_format($c['balance'], 2) ?></td>
      <td><span class="badge badge-<?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
      <td><?= date('d M Y', strtotime($c['issued_date'])) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
