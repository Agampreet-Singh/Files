<?php
require 'includes/auth.php';
require 'config.php';

$totalCustomers = $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$totalCards = $pdo->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$totalBalance = $pdo->query("SELECT COALESCE(SUM(balance),0) FROM cards WHERE status='active'")->fetchColumn();
$todayTx = $pdo->query("SELECT COUNT(*) FROM transactions WHERE DATE(created_at) = CURDATE()")->fetchColumn();

$recent = $pdo->query("SELECT * FROM transactions ORDER BY created_at DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);

require 'includes/header.php';
?>
<div class="page-title">Dashboard</div>
<div class="page-sub">Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?></div>

<div class="stat-grid">
  <div class="stat-card"><div class="label">Total Customers</div><div class="value"><?= $totalCustomers ?></div></div>
  <div class="stat-card"><div class="label">Active Cards</div><div class="value"><?= $totalCards ?></div></div>
  <div class="stat-card"><div class="label">Total Balance (Active)</div><div class="value">₹<?= number_format($totalBalance, 2) ?></div></div>
  <div class="stat-card"><div class="label">Transactions Today</div><div class="value"><?= $todayTx ?></div></div>
</div>

<div class="panel">
  <h3>Recent Transactions</h3>
  <table>
    <tr><th>Card Number</th><th>ATM</th><th>Amount</th><th>Status</th><th>Reason</th><th>Time</th></tr>
    <?php foreach ($recent as $tx): ?>
    <tr>
      <td><?= htmlspecialchars($tx['card_number']) ?></td>
      <td><?= htmlspecialchars($tx['atm_id']) ?></td>
      <td>₹<?= number_format($tx['amount'], 2) ?></td>
      <td><span class="badge badge-<?= $tx['status'] ?>"><?= ucfirst($tx['status']) ?></span></td>
      <td><?= htmlspecialchars($tx['reason']) ?></td>
      <td><?= date('d M, h:i A', strtotime($tx['created_at'])) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($recent)): ?>
    <tr><td colspan="6" style="text-align:center; color:#8a9a9a; padding:24px;">No transactions yet</td></tr>
    <?php endif; ?>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
