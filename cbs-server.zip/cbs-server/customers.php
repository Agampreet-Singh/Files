<?php
require 'includes/auth.php';
require 'config.php';

$customers = $pdo->query("
    SELECT c.*, GROUP_CONCAT(cd.card_number SEPARATOR ', ') AS cards
    FROM customers c
    LEFT JOIN cards cd ON cd.customer_id = c.id
    GROUP BY c.id
    ORDER BY c.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

require 'includes/header.php';
?>
<div class="page-title">Customers</div>
<div class="page-sub">All registered bank customers and their linked cards</div>

<div class="panel">
  <table>
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>KYC ID</th><th>Branch</th><th>Linked Cards</th></tr>
    <?php foreach ($customers as $c): ?>
    <tr>
      <td>#<?= $c['id'] ?></td>
      <td><?= htmlspecialchars($c['full_name']) ?></td>
      <td><?= htmlspecialchars($c['email']) ?></td>
      <td><?= htmlspecialchars($c['phone']) ?></td>
      <td><?= htmlspecialchars($c['kyc_id']) ?></td>
      <td><?= htmlspecialchars($c['branch']) ?></td>
      <td><?= htmlspecialchars($c['cards'] ?? '—') ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
