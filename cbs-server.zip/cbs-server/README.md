# Cosmos Bank — CBS Server Deployment Guide

## What this is
A working Core Banking System (CBS) admin portal:
- Login page (session-based auth)
- Dashboard (customer/card/balance stats + recent transactions)
- Customers listing
- Cards management (add/edit card number, PIN, balance, status) — this is the page the attacker will use to insert a fraudulent card in the attack scenario
- Transaction log with approved/declined filtering

Default login: **username:** `admin`  **password:** `Admin@123`

## Deployment steps (on the CBS Server / Windows Server, already promoted to Domain Controller)

1. **Copy files**
   Copy this entire folder into `C:\xampp\htdocs\cbs\`
   (so the portal loads at `http://localhost/cbs/`)

2. **Import the database**
   - Open **phpMyAdmin** (`http://localhost/phpmyadmin`)
   - Click **Import** → choose `database/schema.sql` → Go
   - This creates the `cosmos_bank` database with sample customers, cards, and transactions

3. **Check `config.php`**
   - If your MySQL root user has a password, update `$DB_PASS` in `config.php`
   - Default XAMPP setup usually has no root password, so it should work as-is

4. **Test it**
   - Go to `http://localhost/cbs/login.php`
   - Log in with `admin` / `Admin@123`
   - Confirm Dashboard, Customers, Cards, and Transactions all load

5. **Enable remote access for the ATM Switch (do this later, once ATM Switch node is set up)**
   Open the commented block at the bottom of `database/schema.sql`, replace `<ATM_SWITCH_IP>` with the actual IP of your ATM Switch machine, and run those 3 lines in phpMyAdmin's SQL tab:
   ```sql
   CREATE USER 'atmswitch'@'<ATM_SWITCH_IP>' IDENTIFIED BY 'ChangeThisPassword!123';
   GRANT SELECT, UPDATE ON cosmos_bank.cards TO 'atmswitch'@'<ATM_SWITCH_IP>';
   GRANT INSERT ON cosmos_bank.transactions TO 'atmswitch'@'<ATM_SWITCH_IP>';
   FLUSH PRIVILEGES;
   ```
   Also make sure MySQL is listening on the network (not just localhost):
   - Edit `C:\xampp\mysql\bin\my.ini`, find `bind-address`, set it to `0.0.0.0` (or comment the line out)
   - Restart MySQL from the XAMPP Control Panel
   - Open Windows Firewall → allow inbound TCP port `3306`

## Notes for the lab scenario
- The **Cards** page is intentionally simple (no validation against duplicate customers, no rate limiting) since it represents the exact database-manipulation step in the attack chain (fake ATM card + balance entry).
- Change the default admin password before treating this as a "hardened" target — as-is, it's meant to be reachable via the Kerberoasting → Pass-the-Hash path your AD setup already provides, not via a portal-login exploit.
