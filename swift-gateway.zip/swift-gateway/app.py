#!/usr/bin/env python3
"""
SWIFT Gateway - Cosmos Bank
Operator portal for creating outgoing international transfers (MT103-style).
On submit: checks & debits the sender's balance on the CBS Server, logs the
transfer locally, and mirrors the transaction into CBS's shared transactions
table (channel = SWIFT) for reconciliation.
"""

import random
import string

import mysql.connector
from flask import Flask, request, redirect, url_for, session, render_template_string
from werkzeug.security import check_password_hash

# ---- Configuration ----
LOCAL_DB = dict(host="localhost", user="swiftapp", password="SwiftApp2024!", database="swift_gateway")

CBS_SERVER_IP = "10.25.0.3"
CBS_DB_USER = "swiftgw"
CBS_DB_PASS = "SwiftGw2024Secure"
CBS_DB_NAME = "cosmos_bank"

app = Flask(__name__)
app.secret_key = "change-this-secret-in-production"  # session cookie signing key


def local_db():
    return mysql.connector.connect(**LOCAL_DB)


def cbs_db():
    return mysql.connector.connect(
        host=CBS_SERVER_IP, port=3306,
        user=CBS_DB_USER, password=CBS_DB_PASS,
        database=CBS_DB_NAME, connection_timeout=5
    )


def gen_mt103_ref():
    return "MT103" + "".join(random.choices(string.digits, k=10))


# ---------------- Templates ----------------

BASE_CSS = """
<style>
  * { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', Arial, sans-serif; }
  body { background:#f4f6f8; color:#1c2b2b; }
  .layout { display:flex; min-height:100vh; }
  .sidebar { width:230px; background:#122a4a; color:#dbe6f5; padding:24px 0; display:flex; flex-direction:column; }
  .sidebar-brand { display:flex; align-items:center; gap:10px; padding:0 20px 24px; border-bottom:1px solid #1d3b63; margin-bottom:20px; }
  .brand-mark { width:36px; height:36px; background:#4a90d9; color:#0a1c33; border-radius:8px; display:flex; align-items:center; justify-content:center; font-weight:700; }
  .brand-name { font-size:15px; font-weight:700; } .brand-sub { font-size:11px; color:#8fa8c8; }
  .sidebar-nav a { padding:12px 22px; color:#b9cbe3; text-decoration:none; font-size:14px; display:block; border-left:3px solid transparent; }
  .sidebar-nav a:hover { background:#1d3b63; color:#fff; }
  .sidebar-nav a.active { background:#1d3b63; color:#fff; border-left-color:#4a90d9; font-weight:600; }
  .logout-link { padding:14px 22px; color:#e0a4a4; text-decoration:none; font-size:13.5px; border-top:1px solid #1d3b63; margin-top:auto; }
  .content { flex:1; padding:32px 40px; }
  .page-title { font-size:22px; font-weight:700; color:#122a4a; margin-bottom:4px; }
  .page-sub { color:#6b7a8a; font-size:13.5px; margin-bottom:28px; }
  .stat-grid { display:grid; grid-template-columns: repeat(3,1fr); gap:20px; margin-bottom:32px; }
  .stat-card { background:#fff; border-radius:10px; padding:20px; border:1px solid #e1e6ee; }
  .stat-card .label { font-size:12.5px; color:#7a8a9a; margin-bottom:8px; }
  .stat-card .value { font-size:24px; font-weight:700; color:#122a4a; }
  .panel { background:#fff; border-radius:10px; border:1px solid #e1e6ee; padding:24px; margin-bottom:24px; }
  .panel h3 { font-size:16px; margin-bottom:16px; color:#122a4a; }
  table { width:100%; border-collapse:collapse; font-size:13.5px; }
  th { text-align:left; padding:10px 12px; background:#f4f6f8; color:#5a6a7a; font-weight:600; border-bottom:2px solid #e1e6ee; }
  td { padding:10px 12px; border-bottom:1px solid #eef1f5; }
  .badge { padding:3px 10px; border-radius:12px; font-size:12px; font-weight:600; }
  .badge-approved { background:#e1f0f5; color:#0f5e8e; } .badge-declined { background:#fcebeb; color:#a32d2d; }
  .btn { display:inline-block; padding:9px 18px; border-radius:6px; font-size:13.5px; font-weight:600; text-decoration:none; border:none; cursor:pointer; }
  .btn-primary { background:#1d5fa8; color:#fff; }
  form.grid-form { display:grid; grid-template-columns: 1fr 1fr; gap:16px; }
  .field { display:flex; flex-direction:column; gap:5px; }
  .field label { font-size:12.5px; color:#5a6a7a; }
  .field input, .field select { padding:9px 10px; border:1px solid #cfd8e2; border-radius:6px; font-size:13.5px; }
  .login-page { min-height:100vh; display:flex; align-items:center; justify-content:center; background:#122a4a; }
  .login-box { background:#fff; border-radius:12px; padding:40px; width:360px; text-align:center; }
  .login-box input { width:100%; padding:11px 12px; border:1px solid #cfd8e2; border-radius:6px; font-size:14px; margin-bottom:14px; }
  .login-box .btn { width:100%; padding:11px; }
  .error-msg { background:#fcebeb; color:#a32d2d; padding:10px 14px; border-radius:6px; font-size:13px; margin-bottom:16px; }
  .success-msg { background:#e1f5ee; color:#0f6e56; padding:10px 14px; border-radius:6px; font-size:13px; margin-bottom:16px; }
</style>
"""

LOGIN_HTML = BASE_CSS + """
<div class="login-page"><div class="login-box">
  <div class="brand-mark" style="margin:0 auto 16px; width:48px; height:48px; font-size:16px;">SG</div>
  <h2 style="color:#122a4a; margin-bottom:6px;">SWIFT Gateway</h2>
  <p style="color:#7a8a9a; font-size:13px; margin-bottom:24px;">Cosmos Bank &mdash; International Transfer Terminal</p>
  {% if error %}<div class="error-msg">{{ error }}</div>{% endif %}
  <form method="POST">
    <input type="text" name="username" placeholder="Operator ID" required autofocus>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" class="btn btn-primary">Sign in</button>
  </form>
</div></div>
"""

LAYOUT_HEAD = BASE_CSS + """
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-mark">SG</div>
      <div><div class="brand-name">SWIFT Gateway</div><div class="brand-sub">Cosmos Bank</div></div>
    </div>
    <nav class="sidebar-nav">
      <a href="/dashboard" class="{{ 'active' if page=='dashboard' else '' }}">Dashboard</a>
      <a href="/new-transfer" class="{{ 'active' if page=='new' else '' }}">New Transfer</a>
      <a href="/transfers" class="{{ 'active' if page=='log' else '' }}">Transfer Log</a>
    </nav>
    <a href="/logout" class="logout-link">Log out</a>
  </aside>
  <main class="content">
"""
LAYOUT_TAIL = "</main></div>"

DASHBOARD_HTML = LAYOUT_HEAD + """
  <div class="page-title">Dashboard</div>
  <div class="page-sub">Welcome back, {{ operator_name }}</div>
  <div class="stat-grid">
    <div class="stat-card"><div class="label">Total Transfers</div><div class="value">{{ total }}</div></div>
    <div class="stat-card"><div class="label">Approved</div><div class="value">{{ approved }}</div></div>
    <div class="stat-card"><div class="label">Total Sent (Approved)</div><div class="value">${{ '%.2f'|format(total_amount) }}</div></div>
  </div>
  <div class="panel">
    <h3>Recent Transfers</h3>
    <table>
      <tr><th>MT103 Ref</th><th>Sender Card</th><th>Beneficiary</th><th>Amount</th><th>Status</th><th>Time</th></tr>
      {% for t in recent %}
      <tr>
        <td>{{ t.mt103_reference }}</td><td>{{ t.sender_card_number }}</td><td>{{ t.beneficiary_name }}</td>
        <td>{{ t.currency }} {{ '%.2f'|format(t.amount) }}</td>
        <td><span class="badge badge-{{ t.status }}">{{ t.status|capitalize }}</span></td>
        <td>{{ t.created_at }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>
""" + LAYOUT_TAIL

NEW_TRANSFER_HTML = LAYOUT_HEAD + """
  <div class="page-title">New International Transfer</div>
  <div class="page-sub">Create an outgoing MT103 payment instruction</div>
  {% if message %}<div class="{{ 'success-msg' if success else 'error-msg' }}">{{ message }}</div>{% endif %}
  <div class="panel">
    <form method="POST" class="grid-form">
      <div class="field"><label>Sender Card / Account Number</label><input type="text" name="sender_card_number" required></div>
      <div class="field"><label>Amount</label><input type="number" step="0.01" name="amount" required></div>
      <div class="field"><label>Currency</label>
        <select name="currency"><option>USD</option><option>EUR</option><option>GBP</option><option>HKD</option></select>
      </div>
      <div class="field"><label>Beneficiary Name</label><input type="text" name="beneficiary_name" required></div>
      <div class="field"><label>Beneficiary Account/IBAN</label><input type="text" name="beneficiary_account" required></div>
      <div class="field"><label>Beneficiary SWIFT/BIC Code</label><input type="text" name="beneficiary_swift_code" required></div>
      <div class="field"><label>Beneficiary Country</label><input type="text" name="beneficiary_country"></div>
      <div></div>
      <div><button type="submit" class="btn btn-primary">Submit Transfer</button></div>
    </form>
  </div>
""" + LAYOUT_TAIL

LOG_HTML = LAYOUT_HEAD + """
  <div class="page-title">Transfer Log</div>
  <div class="page-sub">Full outgoing transfer history</div>
  <div class="panel">
    <table>
      <tr><th>MT103 Ref</th><th>Sender Card</th><th>Beneficiary</th><th>SWIFT/BIC</th><th>Amount</th><th>Status</th><th>Reason</th><th>Time</th></tr>
      {% for t in transfers %}
      <tr>
        <td>{{ t.mt103_reference }}</td><td>{{ t.sender_card_number }}</td><td>{{ t.beneficiary_name }}</td>
        <td>{{ t.beneficiary_swift_code }}</td><td>{{ t.currency }} {{ '%.2f'|format(t.amount) }}</td>
        <td><span class="badge badge-{{ t.status }}">{{ t.status|capitalize }}</span></td>
        <td>{{ t.reason }}</td><td>{{ t.created_at }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>
""" + LAYOUT_TAIL


# ---------------- Routes ----------------

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if "operator_id" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        conn = local_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM operators WHERE username=%s", (request.form["username"],))
        op = cur.fetchone()
        cur.close(); conn.close()
        if op and check_password_hash(op["password_hash"], request.form["password"]):
            session["operator_id"] = op["id"]
            session["operator_name"] = op["full_name"]
            return redirect(url_for("dashboard"))
        error = "Invalid operator ID or password."
    return render_template_string(LOGIN_HTML, error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def require_login():
    return "operator_id" in session


@app.route("/dashboard")
def dashboard():
    if not require_login():
        return redirect(url_for("login"))
    conn = local_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) AS c FROM transfers")
    total = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) AS c FROM transfers WHERE status='approved'")
    approved = cur.fetchone()["c"]
    cur.execute("SELECT COALESCE(SUM(amount),0) AS s FROM transfers WHERE status='approved'")
    total_amount = float(cur.fetchone()["s"])
    cur.execute("SELECT * FROM transfers ORDER BY created_at DESC LIMIT 8")
    recent = cur.fetchall()
    cur.close(); conn.close()
    return render_template_string(DASHBOARD_HTML, page="dashboard",
                                   operator_name=session["operator_name"],
                                   total=total, approved=approved, total_amount=total_amount, recent=recent)


@app.route("/new-transfer", methods=["GET", "POST"])
def new_transfer():
    if not require_login():
        return redirect(url_for("login"))

    message, success = None, False

    if request.method == "POST":
        sender_card = request.form["sender_card_number"].strip()
        amount = float(request.form["amount"])
        currency = request.form["currency"]
        beneficiary_name = request.form["beneficiary_name"]
        beneficiary_account = request.form["beneficiary_account"]
        beneficiary_swift = request.form["beneficiary_swift_code"]
        beneficiary_country = request.form.get("beneficiary_country", "")
        ref = gen_mt103_ref()

        status, reason = "declined", "Unknown error"
        try:
            cbs = cbs_db()
            ccur = cbs.cursor(dictionary=True)
            ccur.execute("SELECT balance, status FROM cards WHERE card_number=%s", (sender_card,))
            card = ccur.fetchone()

            if not card:
                reason = "Sender account not found"
            elif card["status"] != "active":
                reason = "Sender account blocked"
            elif amount > float(card["balance"]):
                reason = "Insufficient balance"
            else:
                ccur.execute("UPDATE cards SET balance = balance - %s WHERE card_number=%s", (amount, sender_card))
                status, reason = "approved", "Transfer processed successfully"

            # Mirror into CBS shared transaction log regardless of outcome
            ccur.execute(
                "INSERT INTO transactions (card_number, atm_id, amount, status, reason) VALUES (%s,%s,%s,%s,%s)",
                (sender_card, "SWIFT", amount, status, reason)
            )
            cbs.commit()
            ccur.close(); cbs.close()

        except mysql.connector.Error as e:
            reason = f"Could not reach CBS Server: {e}"
            status = "declined"

        conn = local_db()
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO transfers
               (mt103_reference, sender_card_number, beneficiary_name, beneficiary_account,
                beneficiary_swift_code, beneficiary_country, amount, currency, status, reason, operator_id)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (ref, sender_card, beneficiary_name, beneficiary_account, beneficiary_swift,
             beneficiary_country, amount, currency, status, reason, session["operator_id"])
        )
        conn.commit()
        cur.close(); conn.close()

        success = status == "approved"
        message = f"{'Approved' if success else 'Declined'} — {reason} (Ref: {ref})"

    return render_template_string(NEW_TRANSFER_HTML, page="new", message=message, success=success)


@app.route("/transfers")
def transfers():
    if not require_login():
        return redirect(url_for("login"))
    conn = local_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM transfers ORDER BY created_at DESC LIMIT 200")
    rows = cur.fetchall()
    cur.close(); conn.close()
    return render_template_string(LOG_HTML, page="log", transfers=rows)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8443)
