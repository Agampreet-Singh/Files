# SWIFT Gateway — Deployment Guide
**Machine:** Ubuntu Server — `10.24.0.4`
**Connects to:** CBS Server — `10.25.0.3`

This node runs an **operator portal** (Flask web app) where a SWIFT operator logs in and creates outgoing international transfers (MT103-style). Every transfer:
1. Checks & debits the sender's balance directly on the CBS Server (`cosmos_bank.cards`)
2. Logs the transfer locally (its own `swift_gateway` database, for the portal's own history)
3. Mirrors the transaction into CBS's shared `transactions` table with `atm_id = 'SWIFT'` — so the blue team can reconcile ATM and SWIFT activity from one place on the CBS dashboard

**Default operator login:** `operator1` / `Swift@123`

This has already been fully tested end-to-end (login → new transfer → balance deducted on CBS → mirrored into CBS transactions → shown in local transfer log).

---

## PART 1 — CBS Server side (do this first, on 10.25.0.3)

Open phpMyAdmin on the CBS Server → **SQL** tab → run `cbs_grant_swift_access.sql` (included in this package). This creates a MySQL user that only `10.24.0.4` can use.

(MySQL should already be listening on the network and port 3306 open in the firewall from the ATM Switch setup — no extra network config needed here.)

---

## PART 2 — SWIFT Gateway machine (10.24.0.4)

### 2.1 — Install MySQL locally (for the operator/transfer log database)
```bash
sudo apt update
sudo apt install -y mysql-server
sudo systemctl enable mysql
sudo systemctl start mysql
```

### 2.2 — Load the local database
Copy `database/schema.sql` to the machine, then:
```bash
sudo mysql < schema.sql
```
This creates the `swift_gateway` database, the `swiftapp` local user (used by the app — not root), the default `operator1` login, and the `transfers` table.

### 2.3 — Install Python + Flask
```bash
sudo apt install -y python3-pip
sudo pip3 install flask mysql-connector-python --break-system-packages
```

### 2.4 — Deploy the app
```bash
sudo mkdir -p /opt/swift-gateway
sudo cp app.py /opt/swift-gateway/
```

### 2.5 — Install as a systemd service
```bash
sudo cp swift-gateway.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable swift-gateway
sudo systemctl start swift-gateway
sudo systemctl status swift-gateway
```

### 2.6 — Test it
From a browser that can reach `10.24.0.4`:
```
http://10.24.0.4:8443/login
```
Log in with `operator1` / `Swift@123`, submit a transfer using a real card number from the CBS database (e.g. `4000123456781001`), and confirm:
- The portal shows "Approved" with an MT103 reference
- CBS Server's **Cards** page shows the reduced balance
- CBS Server's **Transactions** page shows a new row with `ATM = SWIFT`

---

## Notes for the lab scenario

- The operator account (`operator1` / `Swift@123`) is intentionally a simple, guessable credential — this represents the "session/credential theft" step in the attack chain (Mimikatz-dumped or reused password), not a portal exploit. The Red Teamer is expected to already have a foothold (via the AD/Kerberoasting chain) before reaching this machine.
- Because balance changes hit the same `cards` table as the ATM Switch, this node contributes to the exact same audit trail the blue team will use to spot the "approvals without matching authorization" pattern from the real Cosmos Bank case.
- If you want a second, weaker operator account for a more obvious attack path (e.g. `operator2` / `Password123`), just insert another row into `operators` using a Werkzeug password hash — happy to generate one for you.
