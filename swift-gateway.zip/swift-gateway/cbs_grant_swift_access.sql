-- ============================================
-- Run this on CBS Server (10.25.0.3) via phpMyAdmin > SQL tab
-- Allows SWIFT Gateway (10.24.0.4) to check/debit card balances
-- and log transfers into the shared transactions table.
-- ============================================

CREATE USER IF NOT EXISTS 'swiftgw'@'10.24.0.4' IDENTIFIED BY 'SwiftGw2024Secure';

GRANT SELECT, UPDATE ON cosmos_bank.cards TO 'swiftgw'@'10.24.0.4';
GRANT SELECT ON cosmos_bank.customers TO 'swiftgw'@'10.24.0.4';
GRANT INSERT ON cosmos_bank.transactions TO 'swiftgw'@'10.24.0.4';

FLUSH PRIVILEGES;

-- Verify:
-- SELECT user, host FROM mysql.user WHERE user = 'swiftgw';
