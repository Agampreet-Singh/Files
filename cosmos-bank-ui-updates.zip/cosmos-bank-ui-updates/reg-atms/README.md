# Reg. ATMs + City ATMs — Deployment Guide

**Reg. ATMs machine (Ubuntu):** `10.25.0.8` — runs 3 Flask apps (Pune, Mumbai, Hong Kong), one per port
**City ATM machines (Ubuntu, 3 separate nodes):** just run Firefox in kiosk mode, pointing at Reg. ATMs
**Talks to:** ATM Switch — `10.24.0.5:5000`

This has already been fully tested end-to-end (kiosk screen → withdraw → ATM Switch → CBS balance check → approved/declined shown on screen), including both the approved and declined (wrong PIN) cases.

---

## PART 1 — Reg. ATMs machine (10.25.0.8)

### 1.1 — Install Python + Flask
```bash
sudo apt update
sudo apt install -y python3-pip
sudo pip3 install flask --break-system-packages
```

### 1.2 — Deploy the app
```bash
sudo mkdir -p /opt/reg-atms
sudo cp atm_app.py /opt/reg-atms/
```
(The IP for the ATM Switch is already set inside `atm_app.py` as `10.24.0.5` — no need to edit it unless your ATM Switch IP changes.)

### 1.3 — Install all 3 city services
```bash
sudo cp atm-pune.service atm-mumbai.service atm-hongkong.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable atm-pune atm-mumbai atm-hongkong
sudo systemctl start atm-pune atm-mumbai atm-hongkong
sudo systemctl status atm-pune atm-mumbai atm-hongkong
```
All three should show `active (running)`.

### 1.4 — Test from the Reg. ATMs machine itself
```bash
curl -s -X POST http://localhost:8001/api/withdraw -H "Content-Type: application/json" \
  -d '{"card":"4000123456781001","pin":"1234","amount":"1000"}'
```
Expected: `{"reason": "Transaction successful", "status": "APPROVED"}`

Repeat for ports `8002` (Mumbai) and `8003` (Hong Kong) — they all route through the same ATM Switch.

---

## PART 2 — Each City ATM machine (3 separate Ubuntu nodes)

Each of these machines just needs a browser pointed at its city's port on the Reg. ATMs machine — no app code runs here.

### 2.1 — Install Firefox (if not already there)
```bash
sudo apt update
sudo apt install -y firefox
```

### 2.2 — Test manually first
```bash
firefox --kiosk http://10.25.0.8:8001/    # on the Pune ATM machine
firefox --kiosk http://10.25.0.8:8002/    # on the Mumbai ATM machine
firefox --kiosk http://10.25.0.8:8003/    # on the Hong Kong ATM machine
```
Confirm the ATM screen loads full-screen with no browser chrome (no address bar, tabs, or menu).

### 2.3 — Auto-start on boot
On **each** city machine, place the matching `.desktop` file (included — `atm-kiosk-pune.desktop`, `atm-kiosk-mumbai.desktop`, `atm-kiosk-hongkong.desktop`) here:
```bash
mkdir -p ~/.config/autostart
cp atm-kiosk-pune.desktop ~/.config/autostart/   # use the matching file for that machine
```
Reboot the machine — Firefox should launch straight into the ATM kiosk screen with no desktop visible.

### 2.4 — Lock it down further (optional but recommended)
- Right-click is already disabled on the page itself
- To fully prevent someone from exiting kiosk mode, consider disabling the desktop environment's panel/taskbar, or using a minimal window manager with no visible chrome
- `Alt+F4` / `Ctrl+Alt+T` should be disabled at the OS level if you want this airtight (varies by desktop environment — ask if you want a specific one locked down)

---

## How the Whole Chain Works

```
City ATM machine (Firefox kiosk)
        ↓ loads page from
Reg. ATMs (10.25.0.8) — Flask app for that city
        ↓ on withdraw, opens a TCP socket to
ATM Switch (10.24.0.5:5000)
        ↓ queries
CBS Server (10.25.0.3) — cards.balance, cards.pin (bcrypt), status
        ↓ approves/declines, deducts balance, logs transaction
Response flows back up to the kiosk screen
```

## Notes for the lab scenario

- Once the Red Teamer plants the rogue proxy on the ATM Switch (Phase 3), **none of this changes on the ATM/kiosk side** — the kiosk pages and Reg. ATMs Flask apps keep working exactly the same way, since they only ever talk to `10.24.0.5:5000` regardless of whether that's the real switch logic or the rogue proxy. This is intentional — it mirrors the real Cosmos Bank case, where the ATMs themselves were never touched; only the switch in the middle was compromised.
- Each city's `atm_id` (`PUNE`, `MUMBAI`, `HONGKONG`) is sent with every transaction and logged in CBS's `transactions` table — this is what lets the blue team later spot simultaneous withdrawals across multiple cities from the same card, exactly like the real incident's "28 countries in parallel" pattern.
