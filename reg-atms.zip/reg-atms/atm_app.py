#!/usr/bin/env python3
"""
ATM Kiosk Web App - Cosmos Bank
Run one instance per city, each on its own port:
    python3 atm_app.py PUNE 8001
    python3 atm_app.py MUMBAI 8002
    python3 atm_app.py HONGKONG 8003

Each instance serves a kiosk-style ATM screen and forwards withdraw
requests to the ATM Switch over a raw TCP socket (JSON).
"""

import socket
import json
import sys

from flask import Flask, request, jsonify, render_template_string

if len(sys.argv) != 3:
    print("Usage: python3 atm_app.py <ATM_NAME> <PORT>")
    sys.exit(1)

ATM_NAME = sys.argv[1]
PORT = int(sys.argv[2])

ATM_SWITCH_IP = "127.0.0.1"
ATM_SWITCH_PORT = 5000

app = Flask(__name__)

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cosmos Bank ATM</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    background: linear-gradient(160deg, #0a2f2f, #0f4d4d);
    color: white; font-family: 'Segoe UI', Arial, sans-serif;
    height: 100vh; display:flex; align-items:center; justify-content:center;
    overflow: hidden;
  }
  .atm-frame {
    background: #0d1f1f; border-radius: 18px; padding: 36px 40px;
    width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    border: 1px solid #1d4d4d;
  }
  .atm-header { text-align:center; margin-bottom: 24px; }
  .atm-header .bank-name { font-size: 20px; font-weight:700; color:#c9974a; }
  .atm-header .city-name { font-size: 13px; color:#8fb0b0; margin-top:4px; letter-spacing:1px; text-transform:uppercase; }
  .field { margin-bottom: 16px; }
  .field label { display:block; font-size: 12.5px; color:#9fc4c4; margin-bottom: 6px; }
  .field input {
    width:100%; padding: 12px 14px; border-radius: 8px; border:1px solid #1d4d4d;
    background:#122e2e; color:#fff; font-size: 15px; letter-spacing: 1px;
  }
  .field input:focus { outline:none; border-color:#c9974a; }
  button {
    width:100%; padding: 14px; border:none; border-radius: 8px; margin-top: 8px;
    background: #0f6e6e; color:#fff; font-size: 15px; font-weight:600; cursor:pointer;
  }
  button:hover { background:#0a4d4d; }
  #result {
    margin-top: 20px; padding: 14px; border-radius: 8px; text-align:center;
    font-size: 14.5px; display:none;
  }
  #result.approved { background: rgba(30,180,120,0.15); color:#5fe0a8; display:block; }
  #result.declined { background: rgba(220,60,60,0.15); color:#ff8080; display:block; }
  .clock { position:absolute; top:20px; right:30px; font-size:13px; color:#5a8a8a; }
</style>
</head>
<body oncontextmenu="return false">
  <div class="clock" id="clock"></div>
  <div class="atm-frame">
    <div class="atm-header">
      <div class="bank-name">COSMOS BANK</div>
      <div class="city-name">{{ atm_name }} ATM</div>
    </div>
    <div class="field">
      <label>Card Number</label>
      <input id="card" maxlength="16" placeholder="•••• •••• •••• ••••">
    </div>
    <div class="field">
      <label>PIN</label>
      <input id="pin" type="password" maxlength="4" placeholder="••••">
    </div>
    <div class="field">
      <label>Withdrawal Amount</label>
      <input id="amount" placeholder="0.00">
    </div>
    <button onclick="withdraw()">Withdraw Cash</button>
    <div id="result"></div>
  </div>

<script>
document.addEventListener('keydown', e => {
  if (e.key === 'F11' || e.key === 'F12' || e.altKey || (e.ctrlKey && e.shiftKey)) e.preventDefault();
});

function tick() {
  document.getElementById('clock').innerText = new Date().toLocaleTimeString();
}
setInterval(tick, 1000); tick();

function withdraw() {
  const card = document.getElementById('card').value.trim();
  const pin = document.getElementById('pin').value.trim();
  const amount = document.getElementById('amount').value.trim();
  const resultBox = document.getElementById('result');

  if (!card || !pin || !amount) {
    resultBox.className = 'declined';
    resultBox.innerText = 'Please fill in all fields.';
    return;
  }

  resultBox.className = '';

  fetch('/api/withdraw', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({card, pin, amount})
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'APPROVED') {
      resultBox.className = 'approved';
      resultBox.innerText = 'Approved — please collect your cash.';
    } else {
      resultBox.className = 'declined';
      resultBox.innerText = (data.status === 'ERROR' ? 'Switch unavailable — ' : 'Declined — ') + data.reason;
    }
  })
  .catch(() => {
    resultBox.className = 'declined';
    resultBox.innerText = 'Could not reach the ATM switch.';
  });
}
</script>
</body>
</html>
"""


@app.route("/")
def home():
    return render_template_string(HTML_PAGE, atm_name=ATM_NAME)


@app.route("/api/withdraw", methods=["POST"])
def withdraw():
    data = request.json
    payload = {
        "atm_id": ATM_NAME,
        "card": data["card"],
        "pin": data["pin"],
        "amount": data["amount"]
    }
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((ATM_SWITCH_IP, ATM_SWITCH_PORT))
        s.send(json.dumps(payload).encode())
        response = json.loads(s.recv(1024).decode())
        s.close()
        return jsonify(response)
    except Exception as e:
        return jsonify({"status": "ERROR", "reason": str(e)})


if __name__ == "__main__":
    print(f"[{ATM_NAME} ATM] Serving on port {PORT}, forwarding to switch at {ATM_SWITCH_IP}:{ATM_SWITCH_PORT}")
    app.run(host="0.0.0.0", port=PORT)
