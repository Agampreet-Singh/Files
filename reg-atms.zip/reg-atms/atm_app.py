#!/usr/bin/env python3
"""
ATM Kiosk Web App - Cosmos Bank (v2 - full multi-screen flow)
Run one instance per city, each on its own port:
    python3 atm_app.py PUNE 8001
    python3 atm_app.py MUMBAI 8002
    python3 atm_app.py HONGKONG 8003

Screens: Idle -> Insert Card -> PIN pad -> Main Menu ->
         Withdraw / Deposit / Balance / Mini Statement -> Take Card -> Idle
Every action is forwarded to the ATM Switch over a raw TCP socket (JSON).
"""

import socket
import json
import sys

from flask import Flask, request, jsonify, render_template_string

if len(sys.argv) != 3:
    print("Usage: python3 atm_app.py <ATM_NAME> <PORT>")
    sys.exit(1)

ATM_NAME = sys.argv[1]
PORT = int(sys.argv[2])

ATM_SWITCH_IP = "10.24.0.5"
ATM_SWITCH_PORT = 5000

app = Flask(__name__)

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cosmos Bank ATM</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; user-select:none; }
  body {
    background: radial-gradient(circle at 50% 0%, #123a3a, #051515 70%);
    color: white; font-family: 'Segoe UI', Arial, sans-serif;
    height: 100vh; display:flex; align-items:center; justify-content:center;
    overflow: hidden;
  }
  .atm-frame {
    background: #0a1a1a; border-radius: 22px; padding: 0;
    width: 460px; height: 640px; box-shadow: 0 25px 70px rgba(0,0,0,0.6);
    border: 2px solid #1d4d4d; display:flex; flex-direction:column; overflow:hidden;
  }
  .atm-topbar {
    background:#0d2626; padding: 16px 24px; display:flex; align-items:center;
    justify-content:space-between; border-bottom:1px solid #1d4d4d;
  }
  .atm-topbar .bank-name { font-size: 17px; font-weight:700; color:#c9974a; letter-spacing:0.5px; }
  .atm-topbar .city-name { font-size: 11px; color:#7fa8a8; text-transform:uppercase; letter-spacing:1px; }
  .atm-topbar .clock { font-size: 12px; color:#5a8a8a; }
  .atm-body { flex:1; padding: 30px 28px; position:relative; }
  .screen { display:none; height:100%; flex-direction:column; }
  .screen.active { display:flex; }

  #screen-idle { align-items:center; justify-content:center; text-align:center; gap:18px; }
  .card-slot-icon { font-size: 54px; opacity:0.85; }
  #screen-idle h2 { font-size: 20px; color:#eaf4f4; }
  #screen-idle p { font-size: 13px; color:#8fb0b0; max-width:280px; line-height:1.6; }
  .insert-input { margin-top:10px; width:100%; padding:12px 14px; border-radius:8px; border:1px solid #1d4d4d; background:#122e2e; color:#fff; font-size:14px; text-align:center; letter-spacing:2px; }
  .primary-btn { margin-top:6px; width:100%; padding:13px; border:none; border-radius:8px; background:#0f6e6e; color:#fff; font-size:14.5px; font-weight:600; cursor:pointer; }
  .primary-btn:hover { background:#0a4d4d; }

  #screen-pin { align-items:center; gap:16px; }
  .masked-card { font-size:13px; color:#8fb0b0; letter-spacing:2px; }
  .pin-dots { display:flex; gap:14px; margin: 8px 0 4px; }
  .pin-dots .dot { width:16px; height:16px; border-radius:50%; border:1.5px solid #4a8a8a; background:transparent; }
  .pin-dots .dot.filled { background:#c9974a; border-color:#c9974a; }
  .keypad { display:grid; grid-template-columns: repeat(3, 1fr); gap:12px; width:100%; margin-top:10px; }
  .keypad button {
    padding:16px 0; border-radius:10px; border:1px solid #1d4d4d; background:#122e2e;
    color:#fff; font-size:18px; font-weight:600; cursor:pointer;
  }
  .keypad button:hover { background:#1d4d4d; }
  .keypad button.wide { font-size:13px; color:#ff9a9a; }
  .pin-error { color:#ff8080; font-size:12.5px; min-height:16px; }

  #screen-menu { justify-content:flex-start; gap:14px; }
  #screen-menu .menu-title { font-size:15px; color:#8fb0b0; margin-bottom:6px; }
  .menu-grid { display:grid; grid-template-columns: 1fr 1fr; gap:14px; }
  .menu-tile {
    background:#122e2e; border:1px solid #1d4d4d; border-radius:12px; padding:20px 12px;
    text-align:center; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:8px;
  }
  .menu-tile:hover { background:#1d4d4d; border-color:#c9974a; }
  .menu-tile .icon { font-size:26px; }
  .menu-tile .label { font-size:13px; color:#eaf4f4; }
  .exit-tile { grid-column: span 2; background:transparent; border-style:dashed; }
  .exit-tile .label { color:#ff9a9a; }

  .screen-header { font-size:16px; color:#eaf4f4; margin-bottom:18px; }
  .quick-amounts { display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-bottom:16px; }
  .quick-amounts button { padding:14px; border-radius:8px; border:1px solid #1d4d4d; background:#122e2e; color:#fff; font-size:14px; cursor:pointer; }
  .quick-amounts button:hover { background:#1d4d4d; }
  .amount-input { padding:12px 14px; border-radius:8px; border:1px solid #1d4d4d; background:#122e2e; color:#fff; font-size:15px; margin-bottom:16px; }
  .btn-row { display:flex; gap:10px; margin-top:auto; }
  .btn-row button { flex:1; padding:13px; border-radius:8px; border:none; font-size:14px; font-weight:600; cursor:pointer; }
  .btn-confirm { background:#0f6e6e; color:#fff; }
  .btn-back { background:#1d3535; color:#b9cbcb; }

  #screen-processing { align-items:center; justify-content:center; gap:18px; }
  .spinner { width:46px; height:46px; border:4px solid #1d4d4d; border-top-color:#c9974a; border-radius:50%; animation:spin 0.9s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }

  #screen-result { align-items:center; justify-content:center; text-align:center; gap:14px; }
  .result-icon { font-size:46px; }
  .result-message { font-size:15.5px; }
  .result-message.approved { color:#5fe0a8; }
  .result-message.declined { color:#ff8080; }
  .result-balance { font-size:13px; color:#8fb0b0; }

  .balance-amount { font-size:32px; font-weight:700; color:#c9974a; margin: 20px 0; text-align:center; }
  table.mini-stmt { width:100%; border-collapse:collapse; font-size:11.5px; }
  table.mini-stmt th { text-align:left; color:#7fa8a8; padding:6px 4px; border-bottom:1px solid #1d4d4d; }
  table.mini-stmt td { padding:7px 4px; border-bottom:1px solid #16302f; color:#dbeaea; }
  .badge-approved { color:#5fe0a8; } .badge-declined { color:#ff8080; }
</style>
</head>
<body oncontextmenu="return false">
  <div class="atm-frame">
    <div class="atm-topbar">
      <div>
        <div class="bank-name">COSMOS BANK</div>
        <div class="city-name">{{ atm_name }} ATM</div>
      </div>
      <div class="clock" id="clock"></div>
    </div>

    <div class="atm-body">

      <div class="screen active" id="screen-idle">
        <div class="card-slot-icon">[CARD]</div>
        <h2>Welcome to Cosmos Bank</h2>
        <p>Please insert your card to begin. This terminal accepts Cosmos Bank debit cards.</p>
        <input class="insert-input" id="idle-card" maxlength="16" placeholder="Card Number">
        <button class="primary-btn" onclick="insertCard()">Insert Card</button>
      </div>

      <div class="screen" id="screen-pin">
        <div class="masked-card" id="pin-card-label"></div>
        <div class="pin-dots" id="pin-dots">
          <div class="dot"></div><div class="dot"></div><div class="dot"></div><div class="dot"></div>
        </div>
        <div class="pin-error" id="pin-error"></div>
        <div class="keypad" id="keypad">
          <button onclick="keyPress('1')">1</button><button onclick="keyPress('2')">2</button><button onclick="keyPress('3')">3</button>
          <button onclick="keyPress('4')">4</button><button onclick="keyPress('5')">5</button><button onclick="keyPress('6')">6</button>
          <button onclick="keyPress('7')">7</button><button onclick="keyPress('8')">8</button><button onclick="keyPress('9')">9</button>
          <button class="wide" onclick="cancelToIdle()">CANCEL</button><button onclick="keyPress('0')">0</button><button class="wide" onclick="keyClear()">CLEAR</button>
        </div>
        <button class="primary-btn" style="margin-top:14px;" onclick="verifyPin()">ENTER</button>
      </div>

      <div class="screen" id="screen-menu">
        <div class="menu-title">Please select a transaction</div>
        <div class="menu-grid">
          <div class="menu-tile" onclick="showScreen('screen-withdraw')"><div class="icon">[$]</div><div class="label">Withdraw Cash</div></div>
          <div class="menu-tile" onclick="showScreen('screen-deposit')"><div class="icon">[IN]</div><div class="label">Deposit Cash</div></div>
          <div class="menu-tile" onclick="doBalance()"><div class="icon">[BAL]</div><div class="label">Balance Inquiry</div></div>
          <div class="menu-tile" onclick="doMiniStatement()"><div class="icon">[STMT]</div><div class="label">Mini Statement</div></div>
          <div class="menu-tile exit-tile" onclick="takeCard()"><div class="label">Exit / Take Card</div></div>
        </div>
      </div>

      <div class="screen" id="screen-withdraw">
        <div class="screen-header">Withdraw Cash</div>
        <div class="quick-amounts">
          <button onclick="withdrawAmount(500)">Rs. 500</button>
          <button onclick="withdrawAmount(1000)">Rs. 1,000</button>
          <button onclick="withdrawAmount(2000)">Rs. 2,000</button>
          <button onclick="withdrawAmount(5000)">Rs. 5,000</button>
        </div>
        <input class="amount-input" id="withdraw-other" placeholder="Other amount">
        <div class="btn-row">
          <button class="btn-back" onclick="showScreen('screen-menu')">Back</button>
          <button class="btn-confirm" onclick="withdrawAmount(null)">Confirm</button>
        </div>
      </div>

      <div class="screen" id="screen-deposit">
        <div class="screen-header">Deposit Cash</div>
        <input class="amount-input" id="deposit-amount" placeholder="Enter amount to deposit">
        <div class="btn-row">
          <button class="btn-back" onclick="showScreen('screen-menu')">Back</button>
          <button class="btn-confirm" onclick="depositAmount()">Confirm</button>
        </div>
      </div>

      <div class="screen" id="screen-processing">
        <div class="spinner"></div>
        <div>Processing your request...</div>
      </div>

      <div class="screen" id="screen-result">
        <div class="result-icon" id="result-icon"></div>
        <div class="result-message" id="result-message"></div>
        <div class="result-balance" id="result-balance"></div>
        <div class="btn-row" style="width:100%; margin-top:20px;">
          <button class="btn-back" onclick="showScreen('screen-menu')">Another Transaction</button>
          <button class="btn-confirm" onclick="takeCard()">Take Card</button>
        </div>
      </div>

      <div class="screen" id="screen-balance">
        <div class="screen-header">Balance Inquiry</div>
        <div class="balance-amount" id="balance-value"></div>
        <div class="btn-row" style="margin-top:auto;">
          <button class="btn-back" onclick="showScreen('screen-menu')">Back to Menu</button>
          <button class="btn-confirm" onclick="takeCard()">Take Card</button>
        </div>
      </div>

      <div class="screen" id="screen-ministatement">
        <div class="screen-header">Mini Statement (last 5)</div>
        <div style="flex:1; overflow-y:auto;">
          <table class="mini-stmt" id="mini-stmt-table"></table>
        </div>
        <div class="btn-row">
          <button class="btn-back" onclick="showScreen('screen-menu')">Back to Menu</button>
          <button class="btn-confirm" onclick="takeCard()">Take Card</button>
        </div>
      </div>

      <div class="screen" id="screen-takecard">
        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; gap:14px;">
          <div class="card-slot-icon">[OK]</div>
          <div>Thank you. Please take your card.</div>
        </div>
      </div>

    </div>
  </div>

<script>
let session = { card: "", pin: "" };
let pinAttempts = 0;

document.addEventListener('keydown', e => {
  if (e.key === 'F11' || e.key === 'F12' || e.altKey || (e.ctrlKey && e.shiftKey)) e.preventDefault();
});

function tick() { document.getElementById('clock').innerText = new Date().toLocaleTimeString(); }
setInterval(tick, 1000); tick();

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function insertCard() {
  const card = document.getElementById('idle-card').value.trim();
  if (!card) return;
  session.card = card;
  session.pin = "";
  pinAttempts = 0;
  document.getElementById('pin-card-label').innerText = 'Card: **** **** **** ' + card.slice(-4);
  document.getElementById('pin-error').innerText = '';
  updatePinDots();
  showScreen('screen-pin');
}

function updatePinDots() {
  const dots = document.querySelectorAll('#pin-dots .dot');
  dots.forEach((d, i) => d.classList.toggle('filled', i < session.pin.length));
}

function keyPress(digit) {
  if (session.pin.length >= 4) return;
  session.pin += digit;
  updatePinDots();
  if (session.pin.length === 4) verifyPin();
}

function keyClear() {
  session.pin = "";
  document.getElementById('pin-error').innerText = '';
  updatePinDots();
}

function cancelToIdle() {
  session = { card: "", pin: "" };
  document.getElementById('idle-card').value = '';
  showScreen('screen-idle');
}

function callSwitch(action, amount) {
  return fetch('/api/action', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ action, card: session.card, pin: session.pin, amount: amount || 0 })
  }).then(r => r.json());
}

function verifyPin() {
  if (session.pin.length !== 4) {
    document.getElementById('pin-error').innerText = 'Please enter a 4-digit PIN.';
    return;
  }
  callSwitch('verify_pin').then(data => {
    if (data.status === 'APPROVED') {
      showScreen('screen-menu');
    } else {
      pinAttempts++;
      document.getElementById('pin-error').innerText = data.reason + (pinAttempts < 3 ? ' - try again' : '');
      session.pin = "";
      updatePinDots();
      if (pinAttempts >= 3) {
        document.getElementById('pin-error').innerText = 'Too many attempts. Card retained.';
        setTimeout(cancelToIdle, 2000);
      }
    }
  }).catch(() => {
    document.getElementById('pin-error').innerText = 'Switch unavailable.';
    session.pin = ""; updatePinDots();
  });
}

function withdrawAmount(preset) {
  const amount = preset !== null ? preset : parseFloat(document.getElementById('withdraw-other').value);
  if (!amount || amount <= 0) return;
  showScreen('screen-processing');
  callSwitch('withdraw', amount).then(data => renderResult(data)).catch(() => renderResult({status:'ERROR', reason:'Could not reach switch'}));
}

function depositAmount() {
  const amount = parseFloat(document.getElementById('deposit-amount').value);
  if (!amount || amount <= 0) return;
  showScreen('screen-processing');
  callSwitch('deposit', amount).then(data => renderResult(data)).catch(() => renderResult({status:'ERROR', reason:'Could not reach switch'}));
}

function renderResult(data) {
  const approved = data.status === 'APPROVED';
  document.getElementById('result-icon').innerText = approved ? '[OK]' : '[X]';
  const msg = document.getElementById('result-message');
  msg.className = 'result-message ' + (approved ? 'approved' : 'declined');
  msg.innerText = (approved ? 'Approved - ' : 'Declined - ') + data.reason;
  document.getElementById('result-balance').innerText = (data.balance !== undefined) ? ('New balance: Rs. ' + data.balance.toFixed(2)) : '';
  showScreen('screen-result');
}

function doBalance() {
  showScreen('screen-processing');
  callSwitch('balance').then(data => {
    if (data.status === 'APPROVED') {
      document.getElementById('balance-value').innerText = 'Rs. ' + data.balance.toFixed(2);
      showScreen('screen-balance');
    } else {
      renderResult(data);
    }
  });
}

function doMiniStatement() {
  showScreen('screen-processing');
  callSwitch('ministatement').then(data => {
    if (data.status === 'APPROVED') {
      let html = '<tr><th>Date</th><th>ATM</th><th>Amount</th><th>Status</th></tr>';
      data.transactions.forEach(t => {
        html += `<tr><td>${t.created_at}</td><td>${t.atm_id}</td><td>Rs. ${t.amount.toFixed(2)}</td><td class="badge-${t.status}">${t.status}</td></tr>`;
      });
      document.getElementById('mini-stmt-table').innerHTML = html || '<tr><td>No transactions found</td></tr>';
      showScreen('screen-ministatement');
    } else {
      renderResult(data);
    }
  });
}

function takeCard() {
  showScreen('screen-takecard');
  setTimeout(() => {
    session = { card: "", pin: "" };
    document.getElementById('idle-card').value = '';
    showScreen('screen-idle');
  }, 2500);
}
</script>
</body>
</html>
"""


@app.route("/")
def home():
    return render_template_string(HTML_PAGE, atm_name=ATM_NAME)


@app.route("/api/action", methods=["POST"])
def api_action():
    data = request.json
    payload = {
        "atm_id": ATM_NAME,
        "action": data.get("action", "withdraw"),
        "card": data["card"],
        "pin": data["pin"],
        "amount": data.get("amount", 0)
    }
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((ATM_SWITCH_IP, ATM_SWITCH_PORT))
        s.send(json.dumps(payload).encode())
        response = json.loads(s.recv(4096).decode())
        s.close()
        return jsonify(response)
    except Exception as e:
        return jsonify({"status": "ERROR", "reason": str(e)})


if __name__ == "__main__":
    print(f"[{ATM_NAME} ATM] Serving on port {PORT}, forwarding to switch at {ATM_SWITCH_IP}:{ATM_SWITCH_PORT}")
    app.run(host="0.0.0.0", port=PORT)
