#!/usr/bin/env python3
"""
ATM Switch Service - Cosmos Bank
Listens for transaction requests from ATM terminals (JSON over TCP socket),
validates the card against the CBS Server database, and approves/declines.

Run as a systemd service (see atm-switch.service) so it survives reboot.
"""

import socket
import json
import logging
import bcrypt
import mysql.connector
from mysql.connector import Error

# ---- Configuration ----
CBS_SERVER_IP = "10.25.0.3"
CBS_DB_USER = "atmswitch"
CBS_DB_PASS = "AtmSw1tch!2024"
CBS_DB_NAME = "cosmos_bank"

LISTEN_HOST = "0.0.0.0"
LISTEN_PORT = 5000

logging.basicConfig(
    filename="/var/log/atm-switch.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)


def get_cbs_connection():
    return mysql.connector.connect(
        host=CBS_SERVER_IP,
        port=3306,
        user=CBS_DB_USER,
        password=CBS_DB_PASS,
        database=CBS_DB_NAME,
        connection_timeout=5
    )


def process_transaction(atm_id, card_number, pin, amount):
    """Checks the card against CBS, deducts balance if approved, logs the transaction."""
    try:
        conn = get_cbs_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "SELECT balance, pin, status FROM cards WHERE card_number = %s",
            (card_number,)
        )
        card = cursor.fetchone()

        if not card:
            result = {"status": "DECLINED", "reason": "Card not found"}
        elif card["status"] != "active":
            result = {"status": "DECLINED", "reason": "Card blocked"}
        elif not bcrypt.checkpw(str(pin).encode(), str(card["pin"]).encode()):
            result = {"status": "DECLINED", "reason": "Incorrect PIN"}
        elif float(amount) > float(card["balance"]):
            result = {"status": "DECLINED", "reason": "Insufficient balance"}
        else:
            cursor.execute(
                "UPDATE cards SET balance = balance - %s WHERE card_number = %s",
                (amount, card_number)
            )
            result = {"status": "APPROVED", "reason": "Transaction successful"}

        # Log every attempt in the transactions table (this is what the
        # blue team cross-checks later against switch approval counts)
        cursor.execute(
            "INSERT INTO transactions (card_number, atm_id, amount, status, reason) VALUES (%s,%s,%s,%s,%s)",
            (card_number, atm_id, amount, result["status"].lower(), result["reason"])
        )
        conn.commit()
        cursor.close()
        conn.close()

        logging.info(f"ATM={atm_id} CARD={card_number} AMOUNT={amount} -> {result}")
        return result

    except Error as e:
        logging.error(f"DB error for ATM={atm_id} CARD={card_number}: {e}")
        return {"status": "ERROR", "reason": "Switch could not reach CBS Server"}


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((LISTEN_HOST, LISTEN_PORT))
    server.listen(10)
    logging.info(f"ATM Switch listening on {LISTEN_HOST}:{LISTEN_PORT}")
    print(f"[ATM Switch] Listening on {LISTEN_HOST}:{LISTEN_PORT} ...")

    while True:
        client, addr = server.accept()
        try:
            raw = client.recv(1024).decode()
            req = json.loads(raw)
            result = process_transaction(
                req.get("atm_id", "UNKNOWN"),
                req["card"],
                req["pin"],
                req["amount"]
            )
            client.send(json.dumps(result).encode())
        except Exception as e:
            logging.error(f"Bad request from {addr}: {e}")
            client.send(json.dumps({"status": "ERROR", "reason": str(e)}).encode())
        finally:
            client.close()


if __name__ == "__main__":
    start_server()
