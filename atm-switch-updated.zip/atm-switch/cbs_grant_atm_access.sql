-- ============================================
-- Run this on CBS Server (10.25.0.3) via phpMyAdmin > SQL tab
-- This allows the ATM Switch (10.24.0.5) to remotely query/update
-- the cards table and insert transaction records.
-- ============================================

CREATE USER IF NOT EXISTS 'atmswitch'@'10.24.0.5' IDENTIFIED BY 'AtmSw1tch!2024';

GRANT SELECT, UPDATE ON cosmos_bank.cards TO 'atmswitch'@'10.24.0.5';
GRANT SELECT, INSERT ON cosmos_bank.transactions TO 'atmswitch'@'10.24.0.5';

FLUSH PRIVILEGES;

-- Verify the user was created correctly:
-- SELECT user, host FROM mysql.user WHERE user = 'atmswitch';
