# ATM Switch — Deployment Guide
**Machine:** Ubuntu Server — `10.24.0.5`
**Connects to:** CBS Server — `10.25.0.3`

This node has two independent parts:
1. **Oracle WebLogic Server (vulnerable to CVE-2017-10271)** — the entry point the Red Teamer will exploit for RCE
2. **The actual ATM Switch service (Python)** — the real transaction logic that talks to CBS Server's database

They run side by side on the same Ubuntu machine, on different ports. Compromising WebLogic gives the attacker a shell on this box — from there, they interact with (and eventually plant a rogue proxy in front of) the Python switch service.

---

## PART 1 — CBS Server side (do this first, on 10.25.0.3)

Open phpMyAdmin on the CBS Server → **SQL** tab → run `cbs_grant_atm_access.sql` (included in this package). This creates a MySQL user that only `10.24.0.5` can use, with just enough privileges (read/update cards, insert transactions) — not full database access.

Then, still on the CBS Server:
1. Edit `C:\xampp\mysql\bin\my.ini`, find `bind-address`, set it to `0.0.0.0` (or comment the line out)
2. Restart MySQL from the XAMPP Control Panel
3. Windows Firewall → Advanced Settings → Inbound Rules → New Rule → Port → TCP `3306` → Allow

Quick test from the ATM Switch machine once this is done:
```bash
mysql -h 10.25.0.3 -u atmswitch -p'AtmSw1tch!2024' -e "SELECT card_number FROM cosmos_bank.cards LIMIT 1;"
```
If this returns a row, the connection works.

---

## PART 2 — ATM Switch service (Python) — the real transaction logic

1. Copy `atm_switch_service.py` to `/opt/atm-switch/` on the Ubuntu machine:
```bash
sudo mkdir -p /opt/atm-switch
sudo cp atm_switch_service.py /opt/atm-switch/
```

2. Install dependencies:
```bash
sudo apt update
sudo apt install -y python3-pip
sudo pip3 install mysql-connector-python
```

3. Install as a systemd service (so it survives reboot):
```bash
sudo cp atm-switch.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable atm-switch
sudo systemctl start atm-switch
sudo systemctl status atm-switch
```

4. Check logs:
```bash
tail -f /var/log/atm-switch.log
```

5. Test it end-to-end (from any machine that can reach `10.24.0.5:5000`):
```python
import socket, json
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('10.24.0.5', 5000))
s.send(json.dumps({"atm_id": "TEST", "card": "4000123456781001", "pin": "1234", "amount": "2000"}).encode())
print(s.recv(1024).decode())
```
Expected: `{"status": "APPROVED", "reason": "Transaction successful"}` — and the CBS Server's `transactions` table will show a new row.

This part has already been fully tested (all 5 scenarios: approved, wrong PIN, blocked card, insufficient balance, card not found) — it works correctly against a live MySQL database.

---

## PART 3 — Oracle WebLogic Server setup (the vulnerable entry point)

**Goal:** Install a WebLogic version affected by **CVE-2017-10271** (WLS-WSAT XMLDecoder deserialization RCE, unauthenticated) and leave it **unpatched** — i.e. do not apply the October 2017 Critical Patch Update or later.

**Vulnerable versions:** 10.3.6.0, 12.1.2.0, 12.1.3.0, 12.2.1.0, 12.2.1.1, 12.2.1.2 — **12.1.3.0** is the most commonly used version in labs and has the most public exploit PoCs.

### 3.1 — Prerequisites
```bash
sudo apt update
sudo apt install -y openjdk-8-jdk
java -version   # confirm Java 8 is active
```
WebLogic 12.1.3 needs ~2.5 GB disk for install + domain, and runs comfortably with 4 GB RAM allocated to the VM (8 GB recommended if you'll also run heavier tooling on the same box).

### 3.2 — Download WebLogic 12.1.3.0
Oracle requires a free Oracle account to download this (it's not on a public mirror, so I can't fetch it for you directly). From the ATM Switch machine's browser (or download elsewhere and `scp` it over):
- Go to Oracle's software delivery / edelivery site, or Oracle's WebLogic 12.1.3.0 generic installer page
- Download the **Generic Installer** — file is typically named `fmw_12.1.3.0.0_wls_generic.jar` (~1 GB)

### 3.3 — Silent install
```bash
mkdir -p ~/wls_install && cd ~/wls_install
# copy the downloaded jar here

cat > oraInst.loc << 'EOF'
inventory_loc=/opt/oracle/oraInventory
inst_group=oracle
EOF

cat > wls_response.rsp << 'EOF'
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
ORACLE_HOME=/opt/oracle/wls12130
INSTALL_TYPE=WebLogic Server
DECLINE_SECURITY_UPDATES=true
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
EOF

java -jar fmw_12.1.3.0.0_wls_generic.jar -silent \
  -responseFile $(pwd)/wls_response.rsp \
  -invPtrLoc $(pwd)/oraInst.loc
```

### 3.4 — Create a WebLogic domain
```bash
cd /opt/oracle/wls12130/oracle_common/common/bin
./config.sh
```
Run through the wizard (or use `-mode=silent` with a domain template for full automation):
- Domain type: **WebLogic Server Domain**
- Domain name: `atm_switch_domain`
- Admin username: `weblogic` / password: set something like `Weblogic123!` (this becomes the AdminServer login — not part of the attack surface, since CVE-2017-10271 needs no auth)
- Listen port: `7001` (default)

### 3.5 — Start the AdminServer
```bash
cd /opt/oracle/wls12130/user_projects/domains/atm_switch_domain
nohup ./startWebLogic.sh > /var/log/weblogic.log 2>&1 &
```
Wait ~2 minutes for "Server started in RUNNING mode" in the log, then confirm:
```bash
curl -I http://localhost:7001/console
```

### 3.6 — Confirm the vulnerable endpoint is live
```bash
curl -I http://localhost:7001/wls-wsat/CoordinatorPortType11
```
If you get an HTTP response (not a 404), the WSAT web service is deployed and the endpoint is reachable — this is what CVE-2017-10271 targets. **Do not install any WebLogic Patch Set Updates (PSUs) or CPUs after this** — patching removes the vulnerability.

### 3.7 — Auto-start on boot (systemd)
```bash
sudo tee /etc/systemd/system/weblogic.service << 'EOF'
[Unit]
Description=Oracle WebLogic AdminServer
After=network.target

[Service]
Type=forking
ExecStart=/opt/oracle/wls12130/user_projects/domains/atm_switch_domain/startWebLogic.sh
ExecStop=/opt/oracle/wls12130/user_projects/domains/atm_switch_domain/bin/stopWebLogic.sh
User=root
RemainAfterExit=true

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable weblogic
```

### 3.8 — Exploitation reference (for the Red Teamer's side, not the setup)
The Red Teamer will use one of the well-known public PoCs for this CVE — search **"CVE-2017-10271 exploit"** on ExploitDB or GitHub (e.g. `jas502n/CVE-2017-10271`). It sends a crafted SOAP XML payload to `/wls-wsat/CoordinatorPortType11` that triggers OS command execution via `XMLDecoder`. Metasploit also has `exploit/multi/misc/weblogic_wsat_deserialization_rce`. This is the Red Team's job to run during the exercise, not something to pre-configure here.

---

## Port Summary for this Node

| Port | Service | Purpose |
|---|---|---|
| 7001 | WebLogic AdminServer | Vulnerable entry point (CVE-2017-10271) |
| 5000 | ATM Switch Python service | Real transaction processing (talks to CBS on 10.25.0.3:3306) |

Both should show as listening: `sudo ss -tlnp` (or `netstat -tlnp` if installed).
